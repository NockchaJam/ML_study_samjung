from flask import Flask,render_template
import numpy as np
import pickle

app = Flask(__name__)

#http://127.0.0.1:5500/
@app.route('/' , methods = ['GET', 'POST'])
def index():
    aaa  = "헬로 플라스크"

    print(aaa)
    return render_template('index.html')
    # return render_template('index.thml', predict=aaa)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port="5000", debug=True)